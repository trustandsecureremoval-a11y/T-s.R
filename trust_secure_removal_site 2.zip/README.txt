
# Trust & Secure Removal — Static Site (Deploy‑Ready)

This folder is ready to deploy to Vercel, GitHub Pages, Cloudflare Pages, or any cPanel host.

## Important
- **Do NOT add** the number 07450 442222 anywhere. Use **+44 7354 791357** only.
- Contact email: **trustandsecureremoval@gmail.com**.

## Enable the contact forms (static hosting)
The forms use **Web3Forms**, which works on static hosts:

1) Create a free key at https://web3forms.com/ .
2) Copy the Access Key.
3) In `index.html`, `quote.html` and `contact.html`, replace:
```
REPLACE_WITH_YOUR_WEB3FORMS_KEY
```
with your key.
4) Publish. Submissions will go to your email.

## Deploy to Vercel (GitHub method)
1) Create a GitHub repo → upload all files (ensure `index.html` is at the repo root).
2) In Vercel → Import Project → choose your repo → Deploy.
3) Add your domain in Project → Settings → Domains. Set CNAME `www` → `cname.vercel-dns.com` at your registrar.

## Folder structure
- `index.html` (homepage)
- Additional pages: `about.html`, `services.html`, `storage.html`, `quote.html`, `contact.html`, `privacy.html`, `terms.html`
- `css/style.css`
- `assets/logo.svg`

